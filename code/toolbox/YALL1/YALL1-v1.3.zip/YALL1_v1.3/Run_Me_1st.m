addpath(genpath(fileparts(mfilename('fullpath'))));
% if exist('fWHtrans','file') ~= 3
%     cd Utilities;
%     mex -O fWHtrans.cpp
%     cd ..;
% end
disp('Welcome to YALL1')
