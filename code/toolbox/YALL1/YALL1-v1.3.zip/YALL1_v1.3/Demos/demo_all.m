demo_1d
demo_2d
demo_2dw
demo_rand
demo_hard
demo_L1L2
demo_nonneg
demo_complex
demo_weights
demo_L1L2con
close all
