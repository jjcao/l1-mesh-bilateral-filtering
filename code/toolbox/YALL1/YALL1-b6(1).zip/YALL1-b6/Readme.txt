
First run "Run_me_1st" from this directory.  Then you can try any 
of the demo files, but in order to run the 3rd-party codes SPGl1 
and l1_ls (provided you already installed them), you will need to 
edit relevant demo files.

In order to run demo_hard.m, you need to download from the YALL1
site the 2 data files: hard150.mat and hard8nz.mat.

In order to use the discrete Walsh-Hadamard transform, the script
Run_Me_1st.m will try to "mex" the file fastWHtrans.cpp in the 
Utilities directory, which will require a relevant compiler installed 
on your system.

